
import React from 'react';
import { cn } from '@/lib/utils';
import { TaskCategory } from '@/lib/types';

interface CategoryBadgeProps {
  category: TaskCategory;
  className?: string;
}

const categoryStyles: Record<TaskCategory, string> = {
  personal: 'bg-blue-50 text-blue-700 border-blue-200',
  work: 'bg-purple-50 text-purple-700 border-purple-200',
  health: 'bg-green-50 text-green-700 border-green-200',
  finance: 'bg-amber-50 text-amber-700 border-amber-200',
  other: 'bg-gray-50 text-gray-700 border-gray-200',
};

const CategoryBadge = ({ category, className }: CategoryBadgeProps) => {
  return (
    <span 
      className={cn(
        'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium border',
        'transition-all duration-300 ease-in-out',
        categoryStyles[category],
        className
      )}
    >
      {category.charAt(0).toUpperCase() + category.slice(1)}
    </span>
  );
};

export default CategoryBadge;
