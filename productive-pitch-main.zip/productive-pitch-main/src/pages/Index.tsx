
import React, { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { toast } from 'sonner';
import Header from '@/components/layout/Header';
import TaskList from '@/components/tasks/TaskList';
import TaskForm from '@/components/tasks/TaskForm';
import { Task } from '@/lib/types';

const Index = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isFormVisible, setIsFormVisible] = useState(false);
  const [currentTask, setCurrentTask] = useState<Task | undefined>(undefined);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load initial sample tasks
  useEffect(() => {
    // Simulate loading
    setTimeout(() => {
      const sampleTasks: Task[] = [
        {
          id: uuidv4(),
          title: 'Complete project proposal',
          description: 'Finish the proposal document and send it to the client for review.',
          completed: false,
          createdAt: new Date(),
          dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
          category: 'work',
          priority: 'high',
        },
        {
          id: uuidv4(),
          title: 'Go for a run',
          description: '30 minutes morning run in the park',
          completed: false,
          createdAt: new Date(),
          dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // 1 day from now
          category: 'health',
          priority: 'medium',
        },
        {
          id: uuidv4(),
          title: 'Buy groceries',
          description: 'Get fruits, vegetables, and other essentials',
          completed: true,
          createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
          category: 'personal',
          priority: 'low',
        },
      ];
      
      setTasks(sampleTasks);
      setIsLoaded(true);
    }, 300);
  }, []);

  const handleAddNewClick = () => {
    setCurrentTask(undefined);
    setIsFormVisible(true);
  };

  const handleEditTask = (task: Task) => {
    setCurrentTask(task);
    setIsFormVisible(true);
  };

  const handleFormCancel = () => {
    setIsFormVisible(false);
    setCurrentTask(undefined);
  };

  const handleTaskSubmit = (taskData: Omit<Task, 'id' | 'createdAt'> & { id?: string }) => {
    if (taskData.id) {
      // Update existing task
      setTasks(currentTasks => 
        currentTasks.map(task => 
          task.id === taskData.id 
            ? { ...task, ...taskData } 
            : task
        )
      );
      toast.success('Task updated successfully');
    } else {
      // Add new task
      const newTask: Task = {
        ...taskData as Omit<Task, 'id' | 'createdAt'>,
        id: uuidv4(),
        createdAt: new Date(),
      };
      
      setTasks(currentTasks => [newTask, ...currentTasks]);
      toast.success('Task added successfully');
    }
    
    setIsFormVisible(false);
    setCurrentTask(undefined);
  };

  const handleToggleComplete = (id: string) => {
    setTasks(currentTasks => 
      currentTasks.map(task => 
        task.id === id 
          ? { ...task, completed: !task.completed } 
          : task
      )
    );
    
    const task = tasks.find(t => t.id === id);
    if (task) {
      toast.success(task.completed ? 'Task marked as incomplete' : 'Task completed');
    }
  };

  const handleDeleteTask = (id: string) => {
    setTasks(currentTasks => currentTasks.filter(task => task.id !== id));
    toast.success('Task deleted');
  };

  if (!isLoaded) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse-subtle">
          <div className="h-4 w-32 bg-gray-200 rounded mb-4"></div>
          <div className="h-10 w-48 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6">
        <Header />
        
        <main className="mt-6">
          {isFormVisible && (
            <TaskForm 
              task={currentTask}
              onSubmit={handleTaskSubmit}
              onCancel={handleFormCancel}
            />
          )}
          
          <TaskList 
            tasks={tasks}
            onToggleComplete={handleToggleComplete}
            onDelete={handleDeleteTask}
            onEdit={handleEditTask}
            onAddNewClick={handleAddNewClick}
          />
        </main>
      </div>
    </div>
  );
};

export default Index;
