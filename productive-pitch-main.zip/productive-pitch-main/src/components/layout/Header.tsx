
import React from 'react';
import { CheckSquare } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HeaderProps {
  className?: string;
}

const Header = ({ className }: HeaderProps) => {
  return (
    <header className={cn('flex items-center justify-between py-4', className)}>
      <div className="flex items-center">
        <div className="flex items-center text-blue-500 mr-2">
          <CheckSquare size={28} />
        </div>
        <h1 className="text-xl font-medium text-gray-800">Minimal Tasks</h1>
      </div>
      
      <div className="flex items-center space-x-1">
        <button className="p-2 rounded-full hover:bg-gray-100 text-gray-600 transition-colors">
          <span className="sr-only">User profile</span>
          <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 font-medium">
            U
          </div>
        </button>
      </div>
    </header>
  );
};

export default Header;
