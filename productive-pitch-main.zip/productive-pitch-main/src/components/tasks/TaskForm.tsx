
import React, { useState, useEffect } from 'react';
import { CalendarIcon, Clock, X } from 'lucide-react';
import { Task, TaskCategory, TaskPriority } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface TaskFormProps {
  task?: Task;
  onSubmit: (task: Omit<Task, 'id' | 'createdAt'> & { id?: string }) => void;
  onCancel: () => void;
}

const TaskForm = ({ task, onSubmit, onCancel }: TaskFormProps) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [category, setCategory] = useState<TaskCategory>('personal');
  const [priority, setPriority] = useState<TaskPriority>('medium');
  const [formVisible, setFormVisible] = useState(false);

  useEffect(() => {
    if (task) {
      setTitle(task.title);
      setDescription(task.description || '');
      setDueDate(task.dueDate ? format(new Date(task.dueDate), 'yyyy-MM-dd') : '');
      setCategory(task.category);
      setPriority(task.priority);
    }
    
    // Animate the form in after a brief delay
    const timer = setTimeout(() => {
      setFormVisible(true);
    }, 50);
    
    return () => clearTimeout(timer);
  }, [task]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const updatedTask = {
      id: task?.id,
      title,
      description: description || undefined,
      dueDate: dueDate ? new Date(dueDate) : undefined,
      category,
      priority,
      completed: task?.completed || false,
    };
    
    onSubmit(updatedTask);
  };

  const categories: TaskCategory[] = ['personal', 'work', 'health', 'finance', 'other'];
  const priorities: TaskPriority[] = ['low', 'medium', 'high'];

  const priorityStyles: Record<TaskPriority, string> = {
    low: 'bg-blue-50 border-blue-200 text-blue-700',
    medium: 'bg-amber-50 border-amber-200 text-amber-700',
    high: 'bg-red-50 border-red-200 text-red-700',
  };

  return (
    <div className={cn(
      'rounded-lg bg-white p-5 mb-6 border border-gray-100 subtle-shadow',
      'transition-all duration-300 transform',
      formVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'
    )}>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-medium text-gray-800">
          {task ? 'Edit Task' : 'Add New Task'}
        </h2>
        <button 
          onClick={onCancel}
          className="text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X size={20} />
        </button>
      </div>
      
      <form onSubmit={handleSubmit}>
        <div className="space-y-4">
          <div>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Task title"
              required
              className="w-full"
              autoFocus
            />
          </div>
          
          <div>
            <Textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Description (optional)"
              className="w-full resize-none"
              rows={3}
            />
          </div>
          
          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-3">
            <div className="w-full sm:w-1/3">
              <label className="block text-sm font-medium text-gray-600 mb-1">
                Due Date
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                  <CalendarIcon className="h-4 w-4 text-gray-400" />
                </div>
                <Input
                  type="date"
                  value={dueDate}
                  onChange={(e) => setDueDate(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <div className="w-full sm:w-1/3">
              <label className="block text-sm font-medium text-gray-600 mb-1">
                Category
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as TaskCategory)}
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat.charAt(0).toUpperCase() + cat.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="w-full sm:w-1/3">
              <label className="block text-sm font-medium text-gray-600 mb-1">
                Priority
              </label>
              <div className="flex space-x-2">
                {priorities.map((p) => (
                  <label
                    key={p}
                    className={cn(
                      'flex-1 flex items-center justify-center px-3 py-2 rounded-md border text-sm cursor-pointer',
                      'transition-all duration-200',
                      priority === p 
                        ? priorityStyles[p]
                        : 'bg-gray-50 border-gray-200 text-gray-600 hover:bg-gray-100'
                    )}
                  >
                    <input
                      type="radio"
                      name="priority"
                      value={p}
                      checked={priority === p}
                      onChange={() => setPriority(p)}
                      className="sr-only"
                    />
                    {p.charAt(0).toUpperCase() + p.slice(1)}
                  </label>
                ))}
              </div>
            </div>
          </div>
          
          <div className="flex justify-end space-x-3 pt-2">
            <Button
              type="button"
              onClick={onCancel}
              variant="outline"
              className="border-gray-200 text-gray-600 hover:text-gray-700"
            >
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-500 hover:bg-blue-600">
              {task ? 'Update Task' : 'Add Task'}
            </Button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default TaskForm;
