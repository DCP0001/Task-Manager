
import React, { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Check, Clock, Edit, Trash } from 'lucide-react';
import { Task } from '@/lib/types';
import CategoryBadge from '@/components/ui/CategoryBadge';
import { cn } from '@/lib/utils';

interface TaskItemProps {
  task: Task;
  onToggleComplete: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (task: Task) => void;
}

const TaskItem = ({ task, onToggleComplete, onDelete, onEdit }: TaskItemProps) => {
  const [isHovered, setIsHovered] = useState(false);

  const priorityClasses = {
    low: 'border-l-2 border-blue-300',
    medium: 'border-l-2 border-amber-300',
    high: 'border-l-2 border-red-400',
  };

  const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && !task.completed;

  return (
    <div
      className={cn(
        'group p-4 mb-3 rounded-lg bg-white subtle-shadow',
        'task-item-transition',
        priorityClasses[task.priority],
        task.completed ? 'opacity-75' : '',
        isHovered ? 'translate-x-1' : ''
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex items-start justify-between">
        <div className="flex items-start space-x-3 w-full">
          <button
            onClick={() => onToggleComplete(task.id)}
            className={cn(
              'mt-1 w-5 h-5 flex-shrink-0 rounded-full border-2',
              'transition-all duration-300 flex items-center justify-center',
              task.completed
                ? 'bg-blue-500 border-blue-500 text-white'
                : 'border-gray-300'
            )}
          >
            {task.completed && <Check size={14} />}
          </button>
          <div className="flex-1">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <h3
                className={cn(
                  'font-medium text-base',
                  'transition-all duration-300',
                  task.completed ? 'line-through text-gray-400' : 'text-gray-800'
                )}
              >
                {task.title}
              </h3>
              <div className="flex items-center space-x-2 mt-1 sm:mt-0">
                <CategoryBadge category={task.category} />
                {task.dueDate && (
                  <div
                    className={cn(
                      'flex items-center text-xs',
                      isOverdue ? 'text-red-500' : 'text-gray-500'
                    )}
                  >
                    <Clock size={12} className="mr-1" />
                    <span>{formatDistanceToNow(new Date(task.dueDate), { addSuffix: true })}</span>
                  </div>
                )}
              </div>
            </div>
            {task.description && (
              <p
                className={cn(
                  'text-sm mt-1',
                  task.completed ? 'text-gray-400' : 'text-gray-600'
                )}
              >
                {task.description}
              </p>
            )}
          </div>
        </div>
      </div>
      <div
        className={cn(
          'flex items-center justify-end mt-2 space-x-2 opacity-0',
          'transition-opacity duration-300',
          isHovered || task.completed ? 'opacity-100' : ''
        )}
      >
        <button
          onClick={() => onEdit(task)}
          className="p-1 rounded-full text-gray-400 hover:text-blue-500 hover:bg-blue-50 transition-colors"
        >
          <Edit size={16} />
        </button>
        <button
          onClick={() => onDelete(task.id)}
          className="p-1 rounded-full text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors"
        >
          <Trash size={16} />
        </button>
      </div>
    </div>
  );
};

export default TaskItem;
