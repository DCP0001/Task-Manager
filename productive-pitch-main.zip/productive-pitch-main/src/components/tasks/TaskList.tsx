
import React, { useState } from 'react';
import { Plus, List, Grid, Calendar } from 'lucide-react';
import { Task } from '@/lib/types';
import TaskItem from './TaskItem';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface TaskListProps {
  tasks: Task[];
  onToggleComplete: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (task: Task) => void;
  onAddNewClick: () => void;
}

type ViewType = 'list' | 'grid';

const TaskList = ({ tasks, onToggleComplete, onDelete, onEdit, onAddNewClick }: TaskListProps) => {
  const [viewType, setViewType] = useState<ViewType>('list');
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  const filteredTasks = tasks.filter(task => {
    if (filter === 'all') return true;
    if (filter === 'active') return !task.completed;
    if (filter === 'completed') return task.completed;
    return true;
  });

  const activeTasks = tasks.filter(task => !task.completed).length;
  const completedTasks = tasks.filter(task => task.completed).length;

  return (
    <div className="animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <div>
          <h2 className="text-2xl font-medium text-gray-800">My Tasks</h2>
          <p className="text-gray-500 mt-1">
            {activeTasks} active, {completedTasks} completed
          </p>
        </div>
        
        <div className="mt-4 sm:mt-0 flex items-center space-x-3">
          <div className="bg-gray-100 rounded-lg p-1 flex">
            <button
              onClick={() => setFilter('all')}
              className={cn(
                'px-3 py-1 text-sm rounded-md transition-all',
                filter === 'all' 
                  ? 'bg-white text-gray-800 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-800'
              )}
            >
              All
            </button>
            <button
              onClick={() => setFilter('active')}
              className={cn(
                'px-3 py-1 text-sm rounded-md transition-all',
                filter === 'active' 
                  ? 'bg-white text-gray-800 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-800'
              )}
            >
              Active
            </button>
            <button
              onClick={() => setFilter('completed')}
              className={cn(
                'px-3 py-1 text-sm rounded-md transition-all',
                filter === 'completed' 
                  ? 'bg-white text-gray-800 shadow-sm' 
                  : 'text-gray-600 hover:text-gray-800'
              )}
            >
              Completed
            </button>
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewType('list')}
              className={cn(
                'p-2 rounded-md transition-colors',
                viewType === 'list' 
                  ? 'bg-gray-100 text-gray-800' 
                  : 'text-gray-400 hover:text-gray-600'
              )}
            >
              <List size={20} />
            </button>
            <button
              onClick={() => setViewType('grid')}
              className={cn(
                'p-2 rounded-md transition-colors',
                viewType === 'grid' 
                  ? 'bg-gray-100 text-gray-800' 
                  : 'text-gray-400 hover:text-gray-600'
              )}
            >
              <Grid size={20} />
            </button>
          </div>
          
          <Button 
            onClick={onAddNewClick}
            className="bg-blue-500 hover:bg-blue-600 transition-colors"
          >
            <Plus size={18} className="mr-1" />
            New Task
          </Button>
        </div>
      </div>
      
      <div className={cn(
        viewType === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 gap-4' : ''
      )}>
        {filteredTasks.length === 0 ? (
          <div className="bg-white rounded-lg p-8 text-center subtle-shadow">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
              <Calendar className="h-8 w-8 text-gray-400" />
            </div>
            <h3 className="text-gray-800 font-medium mb-1">No tasks found</h3>
            <p className="text-gray-500 mb-4">
              {filter === 'all' 
                ? "You don't have any tasks yet" 
                : filter === 'active' 
                ? "You don't have any active tasks" 
                : "You don't have any completed tasks"}
            </p>
            {filter === 'all' && (
              <Button 
                onClick={onAddNewClick}
                variant="outline"
                className="border-gray-200"
              >
                <Plus size={16} className="mr-1" />
                Add your first task
              </Button>
            )}
          </div>
        ) : (
          filteredTasks.map(task => (
            <TaskItem
              key={task.id}
              task={task}
              onToggleComplete={onToggleComplete}
              onDelete={onDelete}
              onEdit={onEdit}
            />
          ))
        )}
      </div>
    </div>
  );
};

export default TaskList;
